/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors:{
          'back':'#121212',
          'normal-white':'#ffffff',
          'star-blue':'#3BA9CE',
          'dot':'#D9D9D9'
      },
      backgroundImage: {
        'custom-gradient': 'linear-gradient(to right, #3BA9CE 0%, #F80287 100%)', // Replace with your colors
        'custom-gradient1': 'linear-gradient(to right, #000000 1%, #800A4A 33%, #FF1493 100%)'
      },
    },
  },
  plugins: [],
}

